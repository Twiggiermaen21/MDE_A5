/**
 */
package project;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Id Element</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link project.IdElement#getPersonal_id <em>Personal id</em>}</li>
 * </ul>
 *
 * @see project.ProjectPackage#getIdElement()
 * @model
 * @generated
 */
public interface IdElement extends EObject {
	/**
	 * Returns the value of the '<em><b>Personal id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Personal id</em>' attribute.
	 * @see #setPersonal_id(int)
	 * @see project.ProjectPackage#getIdElement_Personal_id()
	 * @model required="true"
	 * @generated
	 */
	int getPersonal_id();

	/**
	 * Sets the value of the '{@link project.IdElement#getPersonal_id <em>Personal id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Personal id</em>' attribute.
	 * @see #getPersonal_id()
	 * @generated
	 */
	void setPersonal_id(int value);

} // IdElement
