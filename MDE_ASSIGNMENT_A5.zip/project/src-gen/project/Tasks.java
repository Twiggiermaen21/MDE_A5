/**
 */
package project;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.Enumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Tasks</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see project.ProjectPackage#getTasks()
 * @model
 * @generated
 */
public enum Tasks implements Enumerator {
	/**
	 * The '<em><b>Teaching</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TEACHING_VALUE
	 * @generated
	 * @ordered
	 */
	TEACHING(0, "teaching", "teaching"),

	/**
	 * The '<em><b>Deputy rector</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DEPUTY_RECTOR_VALUE
	 * @generated
	 * @ordered
	 */
	DEPUTY_RECTOR(1, "deputy_rector", "deputy_rector"),

	/**
	 * The '<em><b>Management university</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MANAGEMENT_UNIVERSITY_VALUE
	 * @generated
	 * @ordered
	 */
	MANAGEMENT_UNIVERSITY(2, "management_university", "management_university");

	/**
	 * The '<em><b>Teaching</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #TEACHING
	 * @model name="teaching"
	 * @generated
	 * @ordered
	 */
	public static final int TEACHING_VALUE = 0;

	/**
	 * The '<em><b>Deputy rector</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DEPUTY_RECTOR
	 * @model name="deputy_rector"
	 * @generated
	 * @ordered
	 */
	public static final int DEPUTY_RECTOR_VALUE = 1;

	/**
	 * The '<em><b>Management university</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MANAGEMENT_UNIVERSITY
	 * @model name="management_university"
	 * @generated
	 * @ordered
	 */
	public static final int MANAGEMENT_UNIVERSITY_VALUE = 2;

	/**
	 * An array of all the '<em><b>Tasks</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final Tasks[] VALUES_ARRAY = new Tasks[] { TEACHING, DEPUTY_RECTOR, MANAGEMENT_UNIVERSITY, };

	/**
	 * A public read-only list of all the '<em><b>Tasks</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List<Tasks> VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Tasks</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param literal the literal.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Tasks get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Tasks result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Tasks</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param name the name.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Tasks getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			Tasks result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Tasks</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the integer value.
	 * @return the matching enumerator or <code>null</code>.
	 * @generated
	 */
	public static Tasks get(int value) {
		switch (value) {
		case TEACHING_VALUE:
			return TEACHING;
		case DEPUTY_RECTOR_VALUE:
			return DEPUTY_RECTOR;
		case MANAGEMENT_UNIVERSITY_VALUE:
			return MANAGEMENT_UNIVERSITY;
		}
		return null;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final int value;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String name;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private final String literal;

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private Tasks(int value, String name, String literal) {
		this.value = value;
		this.name = name;
		this.literal = literal;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int getValue() {
		return value;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getName() {
		return name;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String getLiteral() {
		return literal;
	}

	/**
	 * Returns the literal value of the enumerator, which is its string representation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public String toString() {
		return literal;
	}

} //Tasks
