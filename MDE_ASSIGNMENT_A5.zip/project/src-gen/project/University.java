/**
 */
package project;

import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;
import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>University</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link project.University#getEmployee <em>Employee</em>}</li>
 *   <li>{@link project.University#getDepartment <em>Department</em>}</li>
 * </ul>
 *
 * @see project.ProjectPackage#getUniversity()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='studentUniqueID'"
 * @generated
 */
public interface University extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Employee</b></em>' containment reference list.
	 * The list contents are of type {@link project.Employee}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Employee</em>' containment reference list.
	 * @see project.ProjectPackage#getUniversity_Employee()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Employee> getEmployee();

	/**
	 * Returns the value of the '<em><b>Department</b></em>' containment reference list.
	 * The list contents are of type {@link project.Department}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Department</em>' containment reference list.
	 * @see project.ProjectPackage#getUniversity_Department()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Department> getDepartment();

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='department.course.subject.student.personal_id-&gt;asSet()-&gt;size()= department.course.subject.student.personal_id-&gt;size()'"
	 * @generated
	 */
	boolean studentUniqueID(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='employee.personal_id-&gt;asSet()-&gt;size()= employee.personal_id-&gt;size()'"
	 * @generated
	 */
	boolean employeeUniqueID(DiagnosticChain diagnostics, Map<Object, Object> context);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='department.name-&gt;asSet()-&gt;size()= department.name-&gt;size()'"
	 * @generated
	 */
	boolean departmentUniqueName(DiagnosticChain diagnostics, Map<Object, Object> context);

} // University
