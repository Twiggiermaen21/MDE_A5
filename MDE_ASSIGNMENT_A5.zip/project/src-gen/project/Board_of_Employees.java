/**
 */
package project;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Board of Employees</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link project.Board_of_Employees#getEmployee <em>Employee</em>}</li>
 * </ul>
 *
 * @see project.ProjectPackage#getBoard_of_Employees()
 * @model
 * @generated
 */
public interface Board_of_Employees extends EObject {
	/**
	 * Returns the value of the '<em><b>Employee</b></em>' containment reference list.
	 * The list contents are of type {@link project.Employee}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Employee</em>' containment reference list.
	 * @see project.ProjectPackage#getBoard_of_Employees_Employee()
	 * @model containment="true"
	 * @generated
	 */
	EList<Employee> getEmployee();

} // Board_of_Employees
