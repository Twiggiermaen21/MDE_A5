/**
 */
package project;

import java.util.Map;
import org.eclipse.emf.common.util.DiagnosticChain;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Student</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link project.Student#getDegree <em>Degree</em>}</li>
 *   <li>{@link project.Student#getAge <em>Age</em>}</li>
 * </ul>
 *
 * @see project.ProjectPackage#getStudent()
 * @model annotation="http://www.eclipse.org/emf/2002/Ecore constraints='age'"
 * @generated
 */
public interface Student extends NamedElement, IdElement {
	/**
	 * Returns the value of the '<em><b>Degree</b></em>' attribute.
	 * The literals are from the enumeration {@link project.Degree}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Degree</em>' attribute.
	 * @see project.Degree
	 * @see #setDegree(Degree)
	 * @see project.ProjectPackage#getStudent_Degree()
	 * @model
	 * @generated
	 */
	Degree getDegree();

	/**
	 * Sets the value of the '{@link project.Student#getDegree <em>Degree</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Degree</em>' attribute.
	 * @see project.Degree
	 * @see #getDegree()
	 * @generated
	 */
	void setDegree(Degree value);

	/**
	 * Returns the value of the '<em><b>Age</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Age</em>' attribute.
	 * @see #setAge(int)
	 * @see project.ProjectPackage#getStudent_Age()
	 * @model required="true"
	 * @generated
	 */
	int getAge();

	/**
	 * Sets the value of the '{@link project.Student#getAge <em>Age</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Age</em>' attribute.
	 * @see #getAge()
	 * @generated
	 */
	void setAge(int value);

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @model annotation="http://www.eclipse.org/emf/2002/Ecore/OCL/Pivot body='age &gt;=18'"
	 * @generated
	 */
	boolean age(DiagnosticChain diagnostics, Map<Object, Object> context);

} // Student
