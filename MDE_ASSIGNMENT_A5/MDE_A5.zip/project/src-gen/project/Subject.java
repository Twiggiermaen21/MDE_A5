/**
 */
package project;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Subject</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link project.Subject#getStudent <em>Student</em>}</li>
 * </ul>
 *
 * @see project.ProjectPackage#getSubject()
 * @model
 * @generated
 */
public interface Subject extends NumberElement, NamedElement {
	/**
	 * Returns the value of the '<em><b>Student</b></em>' containment reference list.
	 * The list contents are of type {@link project.Student}.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Student</em>' containment reference list.
	 * @see project.ProjectPackage#getSubject_Student()
	 * @model containment="true"
	 * @generated
	 */
	EList<Student> getStudent();

} // Subject
